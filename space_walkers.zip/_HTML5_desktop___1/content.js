    let bugButton;
    document.addEventListener("mouseup", function(event) {
    const selectedText = window.getSelection().toString().trim();
    const vulnerabilityKeywords = ["|", "OR", "AND", "SQL Injection", "XSS", "get cookie", "browser control"];
    const containsScriptTags = selectedText.includes("<script>") || selectedText.includes("</script>");
    const isVulnerable = vulnerabilityKeywords.some(keyword => selectedText.includes(keyword)) || containsScriptTags;

    if (selectedText && !isInsideInterface(event.target)) {        if (!bugButton) {
        bugButton = document.createElement("button");
        bugButton.style.position = "absolute";        bugButton.style.width = "24px";
        bugButton.style.height = "24px";        bugButton.style.fontSize = "20px";
        bugButton.style.lineHeight = "24px";
        bugButton.style.textAlign = "center";        bugButton.style.background = "transparent";        bugButton.style.border = "none";
        bugButton.style.cursor = "pointer";        
        bugButton.textContent = "🐞";
        document.body.appendChild(bugButton);}
        bugButton.style.top = event.pageY + "px";
        bugButton.style.left = event.pageX + "px";
        bugButton.addEventListener("click", function(event) {
        event.stopPropagation();
        displayResult(isVulnerable); });
    } else { if (bugButton) {
        bugButton.remove();
        bugButton = null; } }
 });
    function displayResult(isVulnerable)
     {    let resultMessage = isVulnerable ? "Bug Detected!\nThe code is vulnerable." : "Not a Bug\nThe code is secure.";
    alert(resultMessage);}
    function isInsideInterface(target) {
    while (target) {
        if (target.classList && target.classList.contains("interfaceDiv")) {
        return true;
        }
        target = target.parentNode;
    }
    return false;
    }
